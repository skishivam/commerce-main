import OpengraphImage from 'components/opengraph-image';

export default async function Image() {
  return await OpengraphImage();
}
